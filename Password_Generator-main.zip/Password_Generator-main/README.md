# About :
 This is a simple yet powerful password generator designed to create unique and secure passwords.
The user has the option to select the length of the password and configure what characters and symbols it should include.

# Features : 
Select password length
Configure what characters and symbols to include in the password
Generate unique and secure passwords
Copy your generated Password to the clipboard

# App Hosted On : 
 Netlify

# Visit & Short URL :
https://passw-gener.netlify.app/

# Demo :

![Screenshot (99)](https://user-images.githubusercontent.com/86542840/232194854-903c5415-ee70-480e-b60f-f21fcd3f9afa.png)







